

echo ""
echo ""
echo "
╭━━━╮╱╱╱╱╱╱╱╱╱╭━━╮╱╱╱╱╱╱╱╱╱╭╮
┃╭━╮┃╱╱╱╱╱╱╱╱╱┃╭╮┃╱╱╱╱╱╱╱╱╭╯╰╮
┃┃╱╰╋━━┳╮╭┳━━╮┃╰╯╰┳━━┳━━┳━┻╮╭╯
┃┃╭━┫╭╮┃╰╯┃┃━┫┃╭━╮┃╭╮┃╭╮┃━━┫┃
┃╰┻━┃╭╮┃┃┃┃┃━┫┃╰━╯┃╰╯┃╰╯┣━━┃╰╮
╰━━━┻╯╰┻┻┻┻━━╯╰━━━┻━━┻━━┻━━┻━╯"
echo " Version 3.4 "
echo ""

sleep 2

echo "
  ✩♬ ₊˚.🎧⋆☾⋆⁺₊✧"
echo " [  DEVICE INFO  ] "
echo ""
sleep 0.5
echo "  デバイス ×  $(getprop ro.product.model) "
sleep 0.5
echo "  ブランド ×  $(getprop ro.product.system.brand) "
sleep 0.5
echo "  モデル   ×  $(getprop ro.build.product) "
sleep 0.5
echo "  カーネル ×  $(uname -r) "

sleep 2


echo ""
echo ""
echo " Installing JIT Game Optimisasi ! "
sleep 5
echo " [■□□□□□□□□□] 10% "
sleep 2
echo " [■■□□□□□□□□] 20% "
sleep 2
echo " [■■■□□□□□□□] 30% "
sleep 2
echo " [■■■■□□□□□□] 40% "
sleep 2
echo " [■■■■■□□□□□] 50% "
sleep 2
echo " [■■■■■■□□□□] 60% "
sleep 2
echo " [■■■■■■■□□□] 70% "
sleep 2
echo " [■■■■■■■■□□] 80% "
sleep 2


#Game Lis
(
cmd package compile -m everything -f com.dts.freefireth
cmd package compile -m speed -f com.dts.freefireth
cmd package compile -m everything -f com.dts.freefiremax
cmd package compile -m speed -f com.dts.freefiremax
cmd package compile -m everything -f com.mobile.legends
cmd package compile -m speed -f com.mobile.legends
cmd package compile -m everything -f com.tencent.ig
cmd package compile -m speed -f com.tencent.ig
cmd package compile -m everything -f com.garena.game.codm
cmd package compile -m speed -f com.garena.game.codm
cmd package compile -m everything -f com.miHoYo.GenshinImpact
cmd package compile -m speed -f com.miHoYo.GenshinImpact
cmd package compile -m everything -f com.ea.gp.nfsm
cmd package compile -m speed -f com.ea.gp.nfsm
cmd package compile -m everything -f com.carxtech.sr
cmd package compile -m speed -f com.carxtech.sr
cmd package compile -m everything -f com.garena.game.lmjx
cmd package compile -m speed -f com.garena.game.lmjx
cmd package compile -m everything -f com.mojang.minecraftpe
cmd package compile -m speed -f com.mojang.minecraftpe
cmd package compile -m everything -f com.HoYoverse.hkrpgoversea
cmd package compile -m speed -f com.HoYoverse.hkrpgoversea
cmd package compile -m everything -f jp.konami.pesam
cmd package compile -m speed -f jp.konami.pesam
cmd package compile -m everything -f com.proximabeta.mf.uamo
cmd package compile -m speed -f com.proximabeta.mf.uamo
cmd package compile -m everything -f com.ea.gp.fifamobile
cmd package compile -m speed -f com.ea.gp.fifamobile
cmd package compile -m everything -f com.miraclegames.farlight84
cmd package compile -m speed -f com.miraclegames.farlight84
cmd package compile -m everything -f com.feralinteractive.gridas
cmd package compile -m speed -f com.feralinteractive.gridas
cmd package compile -m everything -f com.proximabeta.dn2.global
cmd package compile -m speed -f com.proximabeta.dn2.global
cmd package compile -m everything -f com.activision.callofduty.warzone
cmd package compile -m speed -f com.activision.callofduty.warzone
)> /dev/null 2>&1

#Performance
(
setprop debug.OVRPlugin.systemDisplayFrequency 120
setprop debug.OVRManager.cpuLevel 3
setprop debug.OVRManager.gpuLevel 3
setprop debug.performance.tuning 1
setprop debug.texture.scale 16
)> /dev/null 2>&1

sleep 5

echo " [■■■■■■■■■□] 90% "
echo " JIT Game Optimisasi Terpasang ! "
echo ""