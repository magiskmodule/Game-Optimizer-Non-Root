
echo ""
echo ""
echo "
╭━━━╮╱╱╱╱╱╱╱╱╱╭━━╮╱╱╱╱╱╱╱╱╱╭╮
┃╭━╮┃╱╱╱╱╱╱╱╱╱┃╭╮┃╱╱╱╱╱╱╱╱╭╯╰╮
┃┃╱╰╋━━┳╮╭┳━━╮┃╰╯╰┳━━┳━━┳━┻╮╭╯
┃┃╭━┫╭╮┃╰╯┃┃━┫┃╭━╮┃╭╮┃╭╮┃━━┫┃
┃╰┻━┃╭╮┃┃┃┃┃━┫┃╰━╯┃╰╯┃╰╯┣━━┃╰╮
╰━━━┻╯╰┻┻┻┻━━╯╰━━━┻━━┻━━┻━━┻━╯"
echo " Version 3.4 "
echo ""

sleep 2

echo "
  ✩♬ ₊˚.🎧⋆☾⋆⁺₊✧"
echo " [  DEVICE INFO  ] "
echo ""
sleep 0.5
echo "  デバイス ×  $(getprop ro.product.model) "
sleep 0.5
echo "  ブランド ×  $(getprop ro.product.system.brand) "
sleep 0.5
echo "  モデル   ×  $(getprop ro.build.product) "
sleep 0.5
echo "  カーネル ×  $(uname -r) "

sleep 2


echo ""
echo ""
echo " Removed JIT Game Optimisasi ! "
sleep 5
echo " [■□□□□□□□□□] 10% "
sleep 2
echo " [■■□□□□□□□□] 20% "
sleep 2
echo " [■■■□□□□□□□] 30% "
sleep 2
echo " [■■■■□□□□□□] 40% "
sleep 2
echo " [■■■■■□□□□□] 50% "
sleep 2
echo " [■■■■■■□□□□] 60% "
sleep 2
echo " [■■■■■■■□□□] 70% "
sleep 2
echo " [■■■■■■■■□□] 80% "
sleep 2


#Game Remove
(
cmd package compile -m verify -f jp.konami.pesam
cmd package compile -m verify -f com.proximabeta.mf.uamo
cmd package compile -m verify -f com.ea.gp.fifamobile
cmd package compile -m verify -f com.miraclegames.farlight84
cmd package compile -m verify -f com.HoYoverse.hkrpgoversea
cmd package compile -m verify -f com.mojang.minecraftpe
cmd package compile -m verify -f com.garena.game.lmjx
cmd package compile -m verify -f com.garena.game.lmjx
cmd package compile -m verify -f com.carxtech.sr
cmd package compile -m verify -f com.ea.gp.nfsm
cmd package compile -m verify -f com.miHoYo.GenshinImpact
cmd package compile -m verify -f com.garena.game.codm
cmd package compile -m verify -f com.tencent.ig
cmd package compile -m verify -f com.mobile.legends
cmd package compile -m verify -f com.dts.freefiremax
cmd package compile -m verify -f com.dts.freefireth
)> /dev/null 2>&1


sleep 5

echo " [■■■■■■■■■□] 90% "
echo " JIT Game Optimisasi Terhapus ! "
echo ""